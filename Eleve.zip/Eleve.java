public class Eleve {

    private String nom;
    private String prenom;
    private int age;
    private double moyenne;

    public Eleve(String nom, String prenom, int age, double moyenne) {
        this.nom = nom;
        this.prenom = prenom;
        this.age = age;
        this.moyenne = moyenne;
    }

    public String getNom() { return nom; }
    public String getPrenom() { return prenom; }
    public int getAge() { return age; }
    public double getMoyenne() { return moyenne; }

    public void setNom(String nom) { this.nom = nom; }
    public void setPrenom(String prenom) { this.prenom = prenom; }
    public void setAge(int age) { this.age = age; }
    public void setMoyenne(double moyenne) { this.moyenne = moyenne; }

    public String toString() {
        return "Eleve{nom='" + nom + "', prenom='" + prenom +
               "', age=" + age + ", moyenne=" + moyenne + "}";
    }
}
